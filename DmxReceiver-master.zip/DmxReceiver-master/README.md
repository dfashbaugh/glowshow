DmxReceiver by Jim Paris
------------------------

Based on Ward's original
[DmxReceiver](http://forum.pjrc.com/threads/19662?p=24993#post24993)
code.  Requires a Teensy 3.1.

Receives DMX data on `UART0` (Serial1, pin 0).

Usage:

* Copy to Arduino `libraries` directory
* Restart Arduino IDE
* File → Examples → DmxReceiver → DmxTest
* Watch USB serial monitor
